// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBi9SmquqQdsI64SCk1hwYDy2dGunqRmp4",
  authDomain: "tasktrek-46793.firebaseapp.com",
  projectId: "tasktrek-46793",
  storageBucket: "tasktrek-46793.firebasestorage.app",
  messagingSenderId: "331637996444",
  appId: "1:331637996444:web:386a051ead0d7ee60a6659"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Initialize Firestore
const db = firebase.firestore();