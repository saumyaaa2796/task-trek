 let selectedCategory = "All";
let tasks = [];


document.addEventListener("DOMContentLoaded", () => {
  loadTasks();
  

  let toggleBtn = document.getElementById("toggle-btn");
  let sidebar = document.querySelector(".sidebar");
  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("hidden");
  });
});


function loadTasks() {
  db.collection("tasks").orderBy("createdAt").onSnapshot((snapshot) => {
    tasks = [];
    snapshot.forEach((doc) => {
      tasks.push({ id: doc.id, ...doc.data() });
    });
    renderTasks();
    updateProgress();
  });
}


function renderTasks() {
  const taskList = document.getElementById("tasklist");
  taskList.innerHTML = "";
  
  tasks.forEach(task => {
    const li = document.createElement("li");
    li.className = "task-item";
    li.setAttribute("data-id", task.id);
    li.setAttribute("data-category", task.category);

    li.innerHTML = `
      <input type="checkbox" class="task-check" ${task.completed ? "checked" : ""}>
      <span class="task-text">${task.text}</span>
      <button class="renew-btn" title="Renew">♻️</button>
      <button class="delete-btn" title="Delete">🗑️</button>
    `;

  if (task.completed) {
  li.querySelector(".task-text").style.textDecoration = "line-through";
  li.querySelector(".task-text").style.opacity = "0.6";
}

    li.querySelector(".task-check").addEventListener("change", function() {
      db.collection("tasks").doc(task.id).update({
        completed: this.checked
      });
    });

    
    li.querySelector(".renew-btn").addEventListener("click", function() {
      db.collection("tasks").doc(task.id).update({
        completed: false
      });
    });

  
    li.querySelector(".delete-btn").addEventListener("click", function() {
      db.collection("tasks").doc(task.id).delete();
    });

    taskList.appendChild(li);
  });
  
  filterTasksByCategory(selectedCategory);
}


function addTask() {
  const taskInput = document.getElementById("taskinput");
  const taskText = taskInput.value.trim();
  
  if (taskText === "") return;

  db.collection("tasks").add({
    text: taskText,
    category: selectedCategory,
    completed: false,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  }).then(() => {
    taskInput.value = "";
  }).catch((error) => {
    console.error("Error adding task: ", error);
  });
}

function filterTasksByCategory(category) {
  selectedCategory = category;
  const taskElements = document.querySelectorAll("#tasklist .task-item");
  taskElements.forEach(task => {
    const taskCategory = task.getAttribute("data-category");
    task.style.display = (category === "All" || taskCategory === category) ? "flex" : "none";
  });
}


function updateProgress() {
  const total = tasks.length;
  const done = tasks.filter(task => task.completed).length;
  const pending = total - done;

  document.getElementById("total").textContent = `📋 Total: ${total}`;
  document.getElementById("done").textContent = `✅ Done: ${done}`;
  document.getElementById("pending").textContent = `⏳ Pending: ${pending}`;
}

document.querySelectorAll(".category-item").forEach(item => {
  item.addEventListener("click", () => {
    document.querySelectorAll(".category-item").forEach(i => i.classList.remove("active"));
    item.classList.add("active");
    selectedCategory = item.getAttribute("data-category");
    filterTasksByCategory(selectedCategory);
  });
});